let startTime = Date.now();
setInterval(() => {
  const timeSpent = Math.round((Date.now() - startTime) / 1000); // in seconds
  chrome.runtime.sendMessage({ timeSpent });
}, 1000);
