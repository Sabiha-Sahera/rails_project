chrome.webNavigation.onCompleted.addListener((details) => {
    const url = details.url;
    // Send URL to backend
    fetch('http://localhost:3000/visits', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ url })
    });
  });
  